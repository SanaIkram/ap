/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.*;

/**
 *
 * @author test1
 */
public class JavaApplication2 {
 static final String DB_URL = "jdbc:mysql://localhost/";
    static final String USER = "root";
   static final String PASS = "root";
    public String Filename = "D:\\Geo.csv";
   List<City> city = new ArrayList();
    
    
    
   
   
    // inserts all values in database
   public void insertInDB(){
     try {
         City v=null;
         Connection conn = null;
         PreparedStatement stmt = null;
         
         Class.forName("com.mysql.jdbc.Driver");
         
         conn = DriverManager.getConnection(DB_URL, USER, PASS);
        
         String sql="DROP DATABASE IF EXISTS Cities";
         stmt.executeUpdate(sql);
         
  sql = "Insert into CITY(lOCid,country,region,city,postalCode,latitude,longitude,metroCode,areaCode) values(?,?,?,?,?,?,?,?,?)";
		stmt = conn.prepareStatement(sql);
         for (City city1 : city) {
             v = city1;
             stmt.setInt(1, v.locid);
              stmt.setString(2, v.country);
              stmt.setString(3, v.region);
              stmt.setString(4, v.cityy);
              stmt.setString(1, v.postalcode);
              stmt.setDouble(1, v.lat);
              stmt.setDouble(1, v.lon);
              stmt.setString(1, v.metroCode);
              stmt.setString(1, v.areaCode);
         
       stmt.executeUpdate();
        
         
         }
     } catch (ClassNotFoundException ex) {
         Logger.getLogger(JavaApplication2.class.getName()).log(Level.SEVERE, null, ex);
     } catch (SQLException ex) {
         Logger.getLogger(JavaApplication2.class.getName()).log(Level.SEVERE, null, ex);
     }
   }
   
   
    
    //creates Database and tables
    public void CreateDatabase()
   {
        Connection conn = null;
   Statement stmt = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            try {
                conn = DriverManager.getConnection(DB_URL, USER, PASS);
                stmt = conn.createStatement();
      String sql="DROP DATABASE IF EXISTS Cities";
      stmt.executeUpdate(sql);
      sql = "CREATE DATABASE Cities";
      stmt.executeUpdate(sql);
        sql="USE Cities";
      stmt.executeUpdate(sql);
     sql="CREATE TABLE CITY" +
                   "(LOCid INTEGER not NULL AUTO_INCREMENT, " +
                   " country VARCHAR(5), " + 
                   " region VARCHAR(2), " + 
                   " city VARCHAR(2), " + 
                   " postalCode VARCHAR(2), " +
                   " latitude DOUBLE not NULL, " +
                   " longitude DOUBLE not NULL, " +
              
                   " PRIMARY KEY ( LOCid ))"; 
      stmt.executeUpdate(sql);
                
            } catch (SQLException ex) {
                Logger.getLogger(JavaApplication2.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(JavaApplication2.class.getName()).log(Level.SEVERE, null, ex);
        }
   
   }
   
    
    
    
    
    //reads cities from file
   public   List<City> ReadCities(){
  BufferedReader br = null;
	String line = "";
	String cvsSplitBy = ",";
       
        City c = null;
	try {

		br = new BufferedReader(new FileReader(Filename));
                line = br.readLine();
                 line = br.readLine();
		while ((line = br.readLine()) != null) {

		        // use comma as separator
			String[] country = line.split(cvsSplitBy);

			c.locid = parseInt(country[0]);
                        c.country = (country[1]);
                        c.region = country[2];
                         c.cityy = country[3];
                          c.postalcode = country[4];
                        c.lat = parseDouble(country[5]);
                        c.lon = parseDouble(country[6]);
                        c.metroCode = (country[7]);
                        c.areaCode =(country[8]);
                        city.add(c);
		}

	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException ex) {
            Logger.getLogger(JavaApplication2.class.getName()).log(Level.SEVERE, null, ex);
        }

	
   
   return city;
   }
           
    
   
   public void SearchCities(String s) throws SQLException
   {
     try {
         Connection conn = null;
         Statement stmt = null;
         
         Class.forName("com.mysql.jdbc.Driver");
         
         try {
             conn = DriverManager.getConnection(DB_URL, USER, PASS);
         } catch (SQLException ex) {
             Logger.getLogger(JavaApplication2.class.getName()).log(Level.SEVERE, null, ex);
         }
         stmt = conn.createStatement();
         
         
         String sql="Select latitude, longitude from CITY where city="+ s +"";
       ResultSet r=  stmt.executeQuery(sql);
       Double lat = r.getDouble(6);
       Double lon = r.getDouble(7);
       System.out.println(lat);
       System.out.println(lon);
     } catch (ClassNotFoundException ex) {
         Logger.getLogger(JavaApplication2.class.getName()).log(Level.SEVERE, null, ex);
     }
   
   
   
   
   
   
   }
   
 
           
    
    
    
    
    
    public static void main(String[] args) {
        
        
                                                                                                                                                                                              
      
    }
    
}
