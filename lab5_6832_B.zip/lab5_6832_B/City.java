/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author test1
 */
public class City  {
    
 
   List<City> city = new ArrayList();
 public int   locid;
 public String country;
 public String region;
 public String cityy;
 public String postalcode;
 public String metroCode;
 public String  areaCode;
    public double lat;
    public double lon;
            void City(){
  locid = 0;
 country= "";
 lat= 0;
 lon=0;
 String region="";
String cityy="";
 String postalcode="";
 String metroCode="";
 String  areaCode="";


}
   
            
  
    
    
    
   
   
    // inserts all values in database
   
           
}
