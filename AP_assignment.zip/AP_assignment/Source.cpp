#include <stdio.h>
#include <iostream>
#include <string>
#include <time.h>
using namespace std;
//array representing board
int board[101]={0};


//upto four players' positions and status stored in this array PlayersPosition
//the first index stores position on board
//the second index stores if a player is stuck with the snake
int PlayersPosition[4][2] = {0};

//number of players
int numOfPlayers = 2;


//returns a random number between 1 and 6
int throwDice(){

	int r = floor((rand()%6)+1);
	return r;
}



//Creates board and populizes it with snakes and ladders
void CreateBoard(){
	int k=0;
	for(int i =0; i<101; i++)
	{
		board[i]=i;

	}
	//creating three snakes and placing them on random positions
	for(int i= 0; i<3;i++)
	{
		k=floor((rand()%70)+20);
		//make a snake of length between 5 and 15
		board[k]= board[k]-floor((rand()%10)+5);

	}
	//creating three ladders placing them on random positions
	for(int i= 0; i<3;i++)
	{
		k=floor((rand()%70)+10);
		//make a ladder of length between 5 and 15
		board[k]= board[k]+floor((rand()%10)+5);

	}

}


//function used to print the board
void PrintBoard(){
	for(int i=1;i<101; i++ )
	{
		if(board[i]==i)
			cout << "|   "<<i<<"   |";
		else
		{
			if(board[i]<i)
				cout << "|S to "<<board[i]<<" |";
			else{
				if(board[i]>i)
					cout << "|L to "<<board[i]<<" |";


			}


		}
		if(i%10==0)
			cout << "\n\n";

	}






}




//the main function in which the game is played
void Play()
{
	//loop till the game ends
	int win =0;
	while(!win){


		PrintBoard();
		cout<<"---------------------\n";
		cout<<"New round started\n";
		cout<<"---------------------\n";
		cout<<"---------------------\n";
		int i=0;
		int dice = 0;
		//for each player's turn
		for( i=0; i<numOfPlayers; i++)
		{

			dice=throwDice();
			cout <<"Dice returned "<<dice<<" for player "<<i+1<<"\n";

			//if player stuck on snake and dice does not return 6
			if(PlayersPosition[i][1]==1)
			{
				if(dice!=6)
				{
					cout << "Player "<<i+1<<" is stuck with snake\n";
					continue;
				}
				else
				{
					PlayersPosition[i][1]=0; //player free from snake, it can now move
					cout << "Player "<<i+1<<" is now free\n";
				}

			}



			//if everything normal, change the player's position
			if(dice<6 && dice+ PlayersPosition[i][0]<=100 )
			{
				//check if player has landed on snake
				if(PlayersPosition[i][0]+dice>board[PlayersPosition[i][0]+dice])
					PlayersPosition[i][1]=1;
				PlayersPosition[i][0]=  board[PlayersPosition[i][0]+dice];

				//check if won
				if(PlayersPosition[i][0]==100)
				{
					win=1;
					cout << "Player "<<i+1<<" won";
					break;

				}
				cout << "Player "<<i+1<<" at position "<<PlayersPosition[i][0]<<"\n"; 
				continue;

			}

			//if dice is 6, make this move, and play again
			if(dice==6 && dice+ PlayersPosition[i][0]<=100 )
			{
				PlayersPosition[i][0]=  board[PlayersPosition[i][0]+dice];
				cout << "Player "<<i+1<<" at position "<<PlayersPosition[i][0]<<" is given another chance\n";
				i--;
				continue;

			}


			//if move becomes greater than 100
			if(dice+ PlayersPosition[i][0]>100 && dice!=6)
			{
				cout << "Player "<<i+1<<" at position "<<PlayersPosition[i][0]<<"\n";
				continue;
			}
			//if move is greater than 100 but player gets another chance
			if(dice+ PlayersPosition[i][0]>100 && dice==6)
			{
				cout << "Player "<<i+1<<" at position "<<PlayersPosition[i][0]<<"\n";
				i--;
				continue;
			}

		}




	}



}



int main ()
{
	string s = "";
	CreateBoard();

	cout << "Please enter the number of players that will play. It should be between 2 and 4\n";
	cin >> s;
	//keep prompting user to enter right number until he does that
	while(stoi(s)!=2 && stoi(s)!=3 && stoi(s)!=4)

	{
		cout << "it should be between 2 and 4\n";
		cin >> s;


	}
	numOfPlayers = stoi(s);
	cout << numOfPlayers;


	Play();





	
	return 0;
}			
