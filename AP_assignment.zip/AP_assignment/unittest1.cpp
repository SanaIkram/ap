#include "stdafx.h"
#include "CppUnitTest.h"
#include "Header.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest2
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			Header d;
			 Assert(d.throwDice()<= 6);
			  Assert(d.throwDice()>= 1);

	}
}
}