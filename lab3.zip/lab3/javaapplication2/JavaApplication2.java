/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;


import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author test1
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String host = "localhost";
        try {
            // TODO code application logic here
            Scanner user_input = new Scanner( System.in );
            InetAddress serverAddress = InetAddress.getByName(host);
            Socket sender = new Socket(serverAddress,9000);
            
            BufferedReader input;
           //input from server
                input = new BufferedReader(new InputStreamReader(sender.getInputStream()));
            
            
            PrintWriter oserver = new PrintWriter(sender.getOutputStream(),true);
            
            String serverMsg = input.readLine();
            
            System.out.println("Enter username");
            String un = user_input.next();
            //sending username to server
            oserver.println(un);
            serverMsg = input.readLine();
            System.out.println("Press 1 to add notes 2 to retrieve");
           un = user_input.next();
           oserver.println(un);
           if(Integer.parseInt(un)==1)
           {
           //user wants to add notes
            System.out.println("Enter your notes");
             un = user_input.next();
            //sending username to server
            oserver.println(un);
           
           
           }
           else{
           serverMsg = input.readLine();
           
           System.out.println(serverMsg);
           
           }
               
          
            
            
           
            
        } catch (IOException ex) {
            Logger.getLogger(JavaApplication2.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
}
