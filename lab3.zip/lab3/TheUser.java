/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.Vector;
/**
 *
 * @author test1
 */
  public class TheUser implements java.io.Serializable
{
   public String uname;


   public Vector <String> msgs;
  
}


