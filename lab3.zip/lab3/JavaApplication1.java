/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication1;
import javaapplication1.TheUser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Iterator;

/**
 *
 * @author test1
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    

    
   
    
     
    public static void main(String[] args) throws IOException {
       
        ServerSocket listener = new ServerSocket(9000);
        
       
         
try{
	while(true){
	Socket socket = listener.accept();
		try{
		PrintWriter out = new PrintWriter(socket.getOutputStream(),true);
	BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		out.println("Welcome to the Server, Enter username");
		String UserName = input.readLine();
                out.println("Press 1 to add notes 2 to retrieve");
                int opt = Integer.parseInt(input.readLine());
		if(opt ==1)
                {
                //if user chooses to add notes
                    out.println("Please enter your notes");
                    String UserNote = input.readLine();
                    //check if user already present
                    
                     TheUser v = new TheUser();
                             FileInputStream fileIn = new FileInputStream("TheUser.ser");
         ObjectInputStream in = new ObjectInputStream(fileIn);
         while(in.available() > 0 ){
                
                        try {
                            v = (TheUser) in.readObject();
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(JavaApplication1.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        if(v.uname.equals(UserName)){
                            //user already present
                            v.msgs.add(UserNote);
                            
                        } 
                    } 
                    
                    
                    
                    
                    
                    
                    
                    //till here
                    TheUser  u = new TheUser();
                    u.uname = UserName;
                    u.msgs.add(UserNote);
                    
                try{
                    
         FileOutputStream fileOut =
         new FileOutputStream("Users.ser");
         ObjectOutputStream o = new ObjectOutputStream(fileOut);
         o.writeObject(u);
         o.close();
         fileOut.close();
}catch(IOException i){
          i.printStackTrace();
      }

                
                
                
                }
                else
                {
                //if user wants to see notes
                //deserialise
                    TheUser v = new TheUser();
                             FileInputStream fileIn = new FileInputStream("TheUser.ser");
         ObjectInputStream in = new ObjectInputStream(fileIn);
         while(in.available() > 0 ){
                    try {
                        v = (TheUser) in.readObject();
                        if(v.uname.equals(UserName)){
                             Iterator it = v.msgs.iterator();
                       while(it.hasNext())
                        {
                        out.println(it);
                        }
                        } 
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(JavaApplication1.class.getName()).log(Level.SEVERE, null, ex);
                    }
         }
         in.close();

                
                
                
                
                }
		}
		finally{
		socket.close();
		}
	}
}
finally{
listener.close();
}

    }
    
}
