//implements copy on write, reference linking
class COWLString{

	struct node{
	COWLString* val;
	node* next;
	node* prev;
};
	node* head;

  private:
char* _strbuf;                                   //buffer to store the original string
int _length;  



public:
	
    COWLString()
	{
	
	head->val = this;
	
	}//default constructor



	//destructor; would delete the allocated buffer
    ~COWLString()
	{
		//remove the node
		//if only one reference
		if(head->next==head)
	{
	for(int i=0; i< _length; i++)
	{
	free(_strbuf+i);
	
	}
	_strbuf = NULL;
	free(head);
	delete this;
	return;
	}
	 //if not only one reference
		//just remove node, don't delete
		head->prev->next = head->next;
		head->next->prev = head->prev;
		free (head);
		delete head;
	}
	
	
	//constructor to convert a char* to StringBuffer
    COWLString(char* a,int b)
	{
		head->val = this;
		head->next = head;
		head->prev= head;
		
		_strbuf = (char*)malloc(b*sizeof(char));
	for(int i =0; i<b;i++)
	{
	*(this->_strbuf+i)=a[i];
	}
	this->_length=b;
	free(a);
	a= NULL;
	
	
	}

	
	//when this pointer points to another object a
	
	void operator=(COWLString& a)
      {
        //this pointer points to a 
		//this pointer will be added to reference list of a
		 // node* n = new node;
		  head->val = this;
		  a.head->next->prev=head;
		  head->prev = a.head;
		  head->next = a.head->next;
		  a.head->next= head;
		
      }

    char charAt(int i) 
	{
	return *(this->_strbuf+i);
	
	}//returns the character at the passed index

    int length() const
	{
	return _length;
	
	}//returns the length of the buffer

   
	void reserve(int i)
	{
	
_strbuf = (char*)malloc(i*sizeof(char));
	
	}//allocates memory for the string, according to the passed character length



	//appends a single character at the end
    void append(char c)
	{
	//as the string is appended, a copy has to be made
		//it should no longer refer to old string
		

char* temp = (char*)malloc((_length+1)*sizeof(char));
int t_length = _length;
	for(int i =0; i<_length;i++)
	{
	*(temp+i)=*(this->_strbuf+i);
	 
    }
	temp[_length]= c;
	COWLString* p = new COWLString;
	p->_strbuf = temp;
	p->_length = this->_length+1;
	
		}

  

};
