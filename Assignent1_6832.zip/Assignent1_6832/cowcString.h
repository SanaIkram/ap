//copy on write using reference counting
class cowcstring{
	private:
char* _strbuf;                                   //buffer to store the original string
int _length;  

public :
	int refCount;
    

	//destructor; would delete the allocated buffer
    ~cowcstring()
	{
	refCount--;
	if (refCount ==0)
	{
	for(int i=0; i< _length; i++)
	{
	free(_strbuf+i);
	
	}
	_strbuf = NULL;
	
	delete this;
	
	}
	 
	}
	
	
	//constructor to convert a char* to StringBuffer
    cowcstring(char* a,int b)
	{
		refCount++;
		_strbuf = (char*)malloc(b*sizeof(char));
	for(int i =0; i<b;i++)
	{
	*(_strbuf+i)=a[i];
	 
	}
	_length=b;
	free(a);
	a= NULL;
	
	
	}

	
	//when this pointer points to another object
	
	void operator=(cowcstring&  a)
      {
        //this pointer points to a 
		//so increase ref count of a
		a.refCount++;
	//now make them equal
		*this = a;
      }

    char charAt(int i) const
	{
	return *_strbuf+i;
	
	}//returns the character at the passed index

    int length() const
	{
	return _length;
	
	}//returns the length of the buffer

    void reserve(int i)
	{
	
_strbuf = (char*)malloc(i*sizeof(char));
	
	}//allocates memory for the string, according to the passed character length



	//appends a single character at the end
    void append(char c)
	{
	//as the string is appended, a copy has to be made
		//it should no longer refer to old string
		refCount--;

char* temp = (char*)malloc((_length+1)*sizeof(char));
int t_length = _length;
	for(int i =0; i<_length;i++)
	{
	*(temp+i)=*_strbuf+i;
	 
    }
	temp[_length]= c;
	cowcstring* p = new cowcstring;
	p->_strbuf = temp;
	p->_length = _length+1;
	
		}

  
};


