//implements owned pointers


class ownedString{
private:
char* _strbuf;                                   //buffer to store the original string
int _length; 
public :
 

	//destructor; would delete the allocated buffer
  ~ownedString()
	{
	for(int i=0; i< _length; i++)
	{
	free(_strbuf+i);
	
	}
	_strbuf = NULL;
	
	delete this;
	
	}
  char* getbuf()
  {


  return _strbuf;
  
  }
    ownedString( ownedString& a )
	{
	(this->_strbuf) = a.getbuf();
	}
	//constructor to convert a char* to StringBuffer
    ownedString(char* a,int b)
	{
  _strbuf = (char*)malloc(b*sizeof(char));
	for(int i =0; i<b;i++)
	{
	*(this->_strbuf+i)=a[i];
	 
	}
	this->_length=b;
	free(a);
	a= NULL;
	
	}

    char charAt(int i) 
	{
	
	return *this->_strbuf+i;
	
	}//returns the character at the passed index

	int length() {
	return _length;
	
	} //returns the length of the buffer

    void reserve(int a)
	{
	
	_strbuf = (char*)malloc(a*sizeof(char));
	
	}//allocates memory for the string, according to the passed character length

    void append(char a)
	{
	char* temp = (char*)malloc((_length+1)*sizeof(char));

	for(int i =0; i<_length;i++)
	{
	*(temp+i)=*_strbuf+i;
	 
    }
	temp[_length]= c;
	
	_strbuf = temp;
	_length = _length+1;
	delete temp;
	}//appends a single character at the end

   

};


